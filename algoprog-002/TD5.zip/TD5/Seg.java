class Seg {

  // Cette fonction effectue une régression linéaire sur les points allant des
  // indices "d" (début) à "f" (fin). Elle calcule les coefficients "a" et "b"
  // et renvoie également la somme des carrés des erreurs.
  static double[] erreur (double[] xtab, double[] ytab, int d, int f) {

      // A programmer

      // la ligne suivante est fausse et sert juste a permettre la compilation
      return(new double[] {0, 0, 0});

  }

  // Cette fonction calcule le nombre de segments pour un coût donné c.
  static int nbSeg (double[] xtab, double[] ytab, double c) {
     // A programmer

      // la ligne suivante est fausse et sert juste a permettre la compilation
      return(0);

 
  }

}


