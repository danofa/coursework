/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rossin
 */
public class Dictionnaire {
    Noeud racine;

    public boolean existeMot(String s) {
        throw new Error("Méthode à compléter");
    }
    
    public boolean ajouteMot(String s) {
        throw new Error("Méthode à compléter");
    }
    
    public boolean estPrefixe(String s) {
        throw new Error("Méthode à compléter");
        
    }
    
    public void listeMotsAlphabetique() {}
}

class Noeud {
    Noeud(char c) {}
    
    public void ajouteFils(Noeud a) {}
    
}